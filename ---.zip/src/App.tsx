import { useState, useRef, useCallback, useEffect } from 'react';

/* ═══════════════════════════════════════════════════════════════
   TYPES
   ═══════════════════════════════════════════════════════════════ */
interface LogEntry {
  id: number;
  time: string;
  agentId: string;
  agentIcon: string;
  agentName: string;
  message: string;
  type: 'info' | 'search' | 'code' | 'success' | 'error' | 'warning';
}

interface AgentDef {
  id: string;
  name: string;
  icon: string;
  role: string;
  sourceKeys: string[];
  provider: 'nvidia' | 'groq';
  model: string;
  status: 'idle' | 'searching' | 'coding' | 'done' | 'error';
}

/* ═══════════════════════════════════════════════════════════════
   MODELS — 5 NVIDIA + 5 GROQ
   ═══════════════════════════════════════════════════════════════ */
const NVIDIA_MODELS = [
  'meta/llama-3.1-405b-instruct',
  'meta/llama-3.1-70b-instruct',
  'nvidia/llama-3.1-nemotron-70b-instruct',
  'mistralai/mixtral-8x22b-instruct-v0.1',
  'meta/codellama-70b-instruct',
];

const GROQ_MODELS = [
  'llama-3.1-70b-versatile',
  'llama-3.1-8b-instant',
  'mixtral-8x7b-32768',
  'gemma2-9b-it',
  'llama3-70b-8192',
];

/* ═══════════════════════════════════════════════════════════════
   SOURCES — مصادر الأكواد الجاهزة
   ═══════════════════════════════════════════════════════════════ */
const SOURCES: Record<string, { name: string; url: string; desc: string }> = {
  html5up:    { name: 'HTML5 UP',         url: 'https://html5up.net/',                                         desc: '100+ قالب HTML5/CSS3 مجاني' },
  w3css:      { name: 'W3.CSS Templates', url: 'https://www.w3schools.com/w3css/w3css_templates.asp',          desc: 'قوالب W3Schools متنوعة' },
  webflow:    { name: 'Webflow',          url: 'https://webflow.com/made-in-webflow/popular',                  desc: '7000+ قالب HTML مصنفة' },
  code95:     { name: 'Code95',           url: 'https://code95.com/',                                          desc: 'أكواد HTML جاهزة مع أمثلة' },
  purecss:    { name: 'Pure.css',         url: 'https://purecss.io/layouts/',                                  desc: 'إطار عمل CSS خفيف' },
  colorlib:   { name: 'Colorlib',         url: 'https://colorlib.com/wp/cat/flavor/',                          desc: '2500+ تصميم CSS متنوع' },
  flexbox:    { name: 'Flexbox Grid',     url: 'https://css-tricks.com/snippets/css/a-guide-to-flexbox/',      desc: 'تخطيطات شبكية Flexbox' },
  cssCards:   { name: 'CSS Cards',        url: 'https://freefrontend.com/css-cards/',                          desc: 'بطاقات CSS احترافية' },
  timeline:   { name: 'Timelines',        url: 'https://freefrontend.com/css-timelines/',                      desc: 'تخطيطات زمنية رأسية' },
  spotify:    { name: 'Spotify UI',       url: 'https://github.com/nicknish/spotify-artist-page-ui',           desc: 'واجهات متقدمة مع مشغل موسيقى' },
  expanding:  { name: 'Expanding Cols',   url: 'https://codepen.io/trending',                                  desc: 'أعمدة قابلة للتوسع' },
  masonry:    { name: 'CSS Masonry',      url: 'https://codepen.io/search/pens?q=masonry',                     desc: 'تخطيط شبكي ديناميكي' },
  gmaps:      { name: 'Google Maps',      url: 'https://developers.google.com/maps/documentation/javascript',  desc: 'خرائط تفاعلية' },
  unsplash:   { name: 'Unsplash',         url: 'https://unsplash.com/',                                        desc: 'صور مجانية عالية الجودة' },
  fontawesome:{ name: 'Font Awesome',     url: 'https://fontawesome.com/search',                               desc: 'أيقونات احترافية' },
};

/* ═══════════════════════════════════════════════════════════════
   AGENT DEFINITIONS — 10 وكلاء
   ═══════════════════════════════════════════════════════════════ */
const INITIAL_AGENTS: AgentDef[] = [
  { id: 'coordinator',   name: 'المنسق الرئيسي',  icon: '🎯', role: 'تحليل الطلب وتوزيع المهام على الفريق',        sourceKeys: ['html5up','w3css','webflow','purecss','colorlib'],                    provider: 'nvidia', model: NVIDIA_MODELS[0], status: 'idle' },
  { id: 'structure',     name: 'وكيل الهياكل',    icon: '🏗️', role: 'بناء هيكل HTML الكامل للموقع',                 sourceKeys: ['html5up','w3css','webflow','code95'],                               provider: 'groq',   model: GROQ_MODELS[0],   status: 'idle' },
  { id: 'design',        name: 'وكيل التصميم',    icon: '🎨', role: 'كتابة CSS وتنسيق الموقع بالكامل',              sourceKeys: ['purecss','colorlib','flexbox','cssCards'],                           provider: 'nvidia', model: NVIDIA_MODELS[1], status: 'idle' },
  { id: 'interaction',   name: 'وكيل الحركة',     icon: '⚡', role: 'إضافة JavaScript للتفاعل والحركة',             sourceKeys: ['spotify','expanding','masonry','gmaps'],                            provider: 'groq',   model: GROQ_MODELS[2],   status: 'idle' },
  { id: 'content',       name: 'وكيل المحتوى',    icon: '✍️', role: 'كتابة نصوص ومحتوى مناسب للموقع',               sourceKeys: ['html5up','webflow'],                                                provider: 'nvidia', model: NVIDIA_MODELS[3], status: 'idle' },
  { id: 'media',         name: 'وكيل الصور',      icon: '🖼️', role: 'اختيار الصور والأيقونات المناسبة',              sourceKeys: ['unsplash','fontawesome'],                                            provider: 'groq',   model: GROQ_MODELS[1],   status: 'idle' },
  { id: 'reviewer',      name: 'وكيل التدقيق',    icon: '🔍', role: 'مراجعة الكود والتأكد من خلوه من الأخطاء',      sourceKeys: ['html5up','purecss'],                                                provider: 'nvidia', model: NVIDIA_MODELS[4], status: 'idle' },
  { id: 'packager',      name: 'وكيل التغليف',    icon: '📦', role: 'تجميع جميع المخرجات في ملف HTML واحد',         sourceKeys: ['html5up','w3css'],                                                  provider: 'groq',   model: GROQ_MODELS[3],   status: 'idle' },
  { id: 'performance',   name: 'وكيل الأداء',     icon: '🚀', role: 'تحسين أداء وسرعة تحميل الموقع',                sourceKeys: ['purecss','flexbox'],                                                provider: 'nvidia', model: NVIDIA_MODELS[2], status: 'idle' },
  { id: 'compatibility', name: 'وكيل التوافق',    icon: '🌐', role: 'ضمان التوافق مع جميع المتصفحات والأجهزة',     sourceKeys: ['flexbox','cssCards','timeline'],                                     provider: 'groq',   model: GROQ_MODELS[4],   status: 'idle' },
];

/* ═══════════════════════════════════════════════════════════════
   API — استدعاء NVIDIA و Groq
   ═══════════════════════════════════════════════════════════════ */
async function callAI(
  provider: 'nvidia' | 'groq',
  model: string,
  apiKey: string,
  messages: Array<{ role: string; content: string }>,
  maxTokens = 4096,
): Promise<string> {
  const url =
    provider === 'nvidia'
      ? 'https://integrate.api.nvidia.com/v1/chat/completions'
      : 'https://api.groq.com/openai/v1/chat/completions';

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.6,
      max_tokens: maxTokens,
      stream: false,
    }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => 'Unknown');
    throw new Error(`${provider.toUpperCase()} ${res.status}: ${errText.slice(0, 200)}`);
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content ?? '';
}

/* ═══════════════════════════════════════════════════════════════
   SCRAPING — استخراج أكواد من المصادر (BeautifulSoup equivalent)
   يستخدم DOMParser وهو المكافئ الأصلي لـ BeautifulSoup في المتصفح
   ═══════════════════════════════════════════════════════════════ */
async function scrapeSource(url: string): Promise<string> {
  try {
    const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
    const controller = new AbortController();
    const tid = setTimeout(() => controller.abort(), 8000);

    const res = await fetch(proxyUrl, { signal: controller.signal });
    clearTimeout(tid);

    if (!res.ok) return '';
    const html = await res.text();

    // DOMParser = BeautifulSoup المتصفح
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    let snippets = '';

    // استخراج أكواد من عناصر code و pre
    doc.querySelectorAll('code, pre, .code-example, .highlight').forEach((el) => {
      const text = el.textContent || '';
      if (text.length > 40 && snippets.length < 2500) {
        snippets += text.substring(0, 500) + '\n---\n';
      }
    });

    // استخراج هياكل HTML
    if (snippets.length < 500) {
      doc.querySelectorAll('section, article, .card, .template, .example, .demo, .grid, .layout').forEach((el) => {
        const h = (el as HTMLElement).outerHTML;
        if (h.length > 50 && snippets.length < 2500) {
          snippets += h.substring(0, 400) + '\n---\n';
        }
      });
    }

    // استخراج أنماط CSS
    doc.querySelectorAll('style').forEach((el) => {
      const css = el.textContent || '';
      if (css.length > 50 && snippets.length < 3000) {
        snippets += '/* CSS */\n' + css.substring(0, 500) + '\n---\n';
      }
    });

    return snippets.substring(0, 3000);
  } catch {
    return '';
  }
}

/* ═══════════════════════════════════════════════════════════════
   MAIN APP COMPONENT
   ═══════════════════════════════════════════════════════════════ */
export default function App() {
  // ─── Keys ───
  const [nvidiaKey, setNvidiaKey] = useState(() => localStorage.getItem('nv_key') || '');
  const [groqKey, setGroqKey] = useState(() => localStorage.getItem('gq_key') || '');
  const [showSettings, setShowSettings] = useState(false);

  // ─── Input ───
  const [request, setRequest] = useState('');
  const [intervention, setIntervention] = useState('');

  // ─── State ───
  const [agents, setAgents] = useState<AgentDef[]>(INITIAL_AGENTS.map((a) => ({ ...a })));
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [finalCode, setFinalCode] = useState('');
  const [activeTab, setActiveTab] = useState<'log' | 'code' | 'preview'>('log');
  const [phase, setPhase] = useState('');
  const [copied, setCopied] = useState(false);

  const logId = useRef(0);
  const logEndRef = useRef<HTMLDivElement>(null);
  const interventionRef = useRef('');

  useEffect(() => { interventionRef.current = intervention; }, [intervention]);
  useEffect(() => { localStorage.setItem('nv_key', nvidiaKey); }, [nvidiaKey]);
  useEffect(() => { localStorage.setItem('gq_key', groqKey); }, [groqKey]);
  useEffect(() => { logEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [logs]);

  // ─── Helpers ───
  const addLog = useCallback((agentId: string, message: string, type: LogEntry['type'] = 'info') => {
    const ag = INITIAL_AGENTS.find((a) => a.id === agentId);
    setLogs((prev) => [
      ...prev,
      {
        id: ++logId.current,
        time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        agentId,
        agentIcon: ag?.icon || '📋',
        agentName: ag?.name || 'النظام',
        message,
        type,
      },
    ]);
  }, []);

  const setStatus = useCallback((id: string, status: AgentDef['status']) => {
    setAgents((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
  }, []);

  const getKey = useCallback(
    (p: 'nvidia' | 'groq') => (p === 'nvidia' ? nvidiaKey : groqKey),
    [nvidiaKey, groqKey],
  );

  /* ─── Run single agent ─── */
  const runAgent = useCallback(
    async (
      agentId: string,
      systemPrompt: string,
      userPrompt: string,
      doScrape = true,
      maxTokens = 4096,
    ): Promise<string> => {
      const agent = INITIAL_AGENTS.find((a) => a.id === agentId)!;
      const key = getKey(agent.provider);
      if (!key) throw new Error(`مفتاح ${agent.provider.toUpperCase()} غير مُدخل`);

      let sourceSnippets = '';

      if (doScrape && agent.sourceKeys.length > 0) {
        setStatus(agentId, 'searching');
        const toScrape = agent.sourceKeys.slice(0, 2);
        for (const sk of toScrape) {
          const src = SOURCES[sk];
          if (!src) continue;
          addLog(agentId, `🔍 بحث في ${src.name} (${src.desc})...`, 'search');
          const snippet = await scrapeSource(src.url);
          if (snippet) {
            sourceSnippets += `\n/* === ${src.name} === */\n${snippet}\n`;
            addLog(agentId, `✅ تم استخراج أكواد من ${src.name}`, 'success');
          } else {
            addLog(agentId, `⚠️ تعذر الوصول لـ ${src.name}، الاعتماد على الذكاء الاصطناعي`, 'warning');
          }
        }
      }

      setStatus(agentId, 'coding');
      addLog(agentId, `💻 ${agent.role}...`, 'code');

      const fullSystem = sourceSnippets
        ? `${systemPrompt}\n\nأكواد مرجعية مستخرجة من مصادر احترافية:\n${sourceSnippets}`
        : systemPrompt;

      const interv = interventionRef.current;
      const fullUser = interv ? `${userPrompt}\n\nتعليمات إضافية من المستخدم: ${interv}` : userPrompt;

      const result = await callAI(agent.provider, agent.model, key, [
        { role: 'system', content: fullSystem },
        { role: 'user', content: fullUser },
      ], maxTokens);

      setStatus(agentId, 'done');
      addLog(agentId, `✅ اكتمل بنجاح`, 'success');
      return result;
    },
    [addLog, getKey, setStatus],
  );

  /* ═══════════════════════════════════════════════════════════════
     WORKFLOW — سير عمل الوكلاء الكامل
     ═══════════════════════════════════════════════════════════════ */
  const startWorkflow = useCallback(async () => {
    if (!nvidiaKey || !groqKey) {
      setShowSettings(true);
      return;
    }
    if (!request.trim()) return;

    setIsRunning(true);
    setFinalCode('');
    setLogs([]);
    setAgents(INITIAL_AGENTS.map((a) => ({ ...a, status: 'idle' as const })));
    setActiveTab('log');

    try {
      /* ── المرحلة 1: التنسيق ── */
      setPhase('📋 المرحلة 1: تحليل الطلب وإنشاء الخطة');
      addLog('coordinator', '🎯 بدء تحليل الطلب وإنشاء خطة العمل...', 'info');

      const plan = await runAgent(
        'coordinator',
        `أنت المنسق الرئيسي لفريق من 10 وكلاء ذكاء اصطناعي متخصصين في بناء مواقع الويب.
حلل طلب المستخدم وأنشئ خطة عمل مفصلة.

أجب بصيغة JSON فقط:
{
  "siteName": "اسم الموقع",
  "siteType": "نوع الموقع",
  "colorScheme": {"primary": "#hex", "secondary": "#hex", "accent": "#hex", "bg": "#hex", "text": "#hex"},
  "sections": ["قائمة الأقسام"],
  "features": ["قائمة الميزات"],
  "style": "modern/classic/minimal",
  "tasks": {
    "structure": "مهمة وكيل الهياكل بالتفصيل",
    "design": "مهمة وكيل التصميم بالتفصيل",
    "interaction": "مهمة وكيل الحركة بالتفصيل",
    "content": "مهمة وكيل المحتوى بالتفصيل",
    "media": "مهمة وكيل الصور بالتفصيل"
  }
}`,
        `أنشئ خطة لبناء موقع: ${request}`,
        false,
        2048,
      );

      addLog('coordinator', '📋 تم إنشاء خطة العمل بنجاح، جاري توزيع المهام...', 'success');

      /* ── المرحلة 2: العمل المتوازي (5 وكلاء) ── */
      setPhase('🚀 المرحلة 2: البحث في المصادر والإنشاء المتوازي');
      addLog('coordinator', '🚀 إطلاق 5 وكلاء للعمل بالتوازي...', 'info');

      const [htmlR, cssR, jsR, contentR, mediaR] = await Promise.allSettled([
        runAgent(
          'structure',
          `أنت مطور HTML5 خبير. أنشئ هيكل HTML كامل ومتجاوب للموقع.
- استخدم عناصر HTML5 الدلالية (header, nav, main, section, article, footer)
- أضف meta tags مناسبة وخصائص إمكانية الوصول
- استخدم أسماء classes واضحة بنمط BEM
- اجعل الهيكل مناسب للمحتوى العربي (RTL)
- أخرج فقط كود HTML داخل body (بدون html/head)`,
          `ابنِ هيكل HTML بناءً على هذه الخطة:\n${plan}`,
          true,
          4096,
        ),

        runAgent(
          'design',
          `أنت مصمم CSS3 خبير. أنشئ تنسيقات CSS جميلة ومتجاوبة.
- استخدم CSS Grid و Flexbox للتخطيطات
- أضف انتقالات سلسة وتأثيرات hover
- اجعل التصميم متجاوب (mobile-first)
- استخدم CSS Custom Properties للألوان
- أضف تأثيرات gradient وshadow احترافية
- ادعم اتجاه RTL
- أخرج فقط كود CSS (بدون HTML)`,
          `أنشئ تنسيقات CSS بناءً على الخطة:\n${plan}`,
          true,
          4096,
        ),

        runAgent(
          'interaction',
          `أنت مطور JavaScript خبير. أضف تفاعلات وحركات للموقع.
- استخدم Vanilla JS فقط (بدون مكتبات)
- أضف: تمرير سلس، قائمة موبايل متحركة، أنيميشن عند التمرير
- أضف تحقق من النماذج إن وُجدت
- أضف تأثيرات بصرية احترافية
- أخرج فقط كود JavaScript`,
          `أضف تفاعلات بناءً على الخطة:\n${plan}`,
          true,
          3072,
        ),

        runAgent(
          'content',
          `أنت كاتب محتوى خبير. اكتب نصوص موقع ويب احترافية باللغة العربية.
أخرج بصيغة JSON:
{"sections": [{"id": "section-id", "title": "العنوان", "subtitle": "العنوان الفرعي", "text": "النص", "cta": "نص الزر"}]}`,
          `اكتب محتوى للموقع بناءً على الخطة:\n${plan}`,
          false,
          2048,
        ),

        runAgent(
          'media',
          `أنت متخصص في اختيار الوسائط. اختر صور وأيقونات مناسبة.
- للصور استخدم: https://images.unsplash.com/photo-[ID]?w=800&h=600&fit=crop
- أو استخدم placeholder: https://placehold.co/800x600/[bg-hex]/[text-hex]?text=[text]
- للأيقونات استخدم Font Awesome 6 (CDN: https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css)
أخرج بصيغة JSON:
{"images": [{"section": "id", "url": "url", "alt": "وصف"}], "iconsCDN": "رابط CDN", "icons": [{"class": "fa-solid fa-name", "usage": "أين"}]}`,
          `اختر وسائط للموقع بناءً على الخطة:\n${plan}`,
          false,
          1024,
        ),
      ]);

      const html = htmlR.status === 'fulfilled' ? htmlR.value : '<div class="error">خطأ في بناء الهيكل</div>';
      const css = cssR.status === 'fulfilled' ? cssR.value : 'body{font-family:sans-serif}';
      const js = jsR.status === 'fulfilled' ? jsR.value : '';
      const content = contentR.status === 'fulfilled' ? contentR.value : '{}';
      const media = mediaR.status === 'fulfilled' ? mediaR.value : '{}';

      // تسجيل الأخطاء
      const ids = ['structure', 'design', 'interaction', 'content', 'media'];
      [htmlR, cssR, jsR, contentR, mediaR].forEach((r, i) => {
        if (r.status === 'rejected') {
          setStatus(ids[i], 'error');
          addLog(ids[i], `❌ ${r.reason?.message || 'خطأ غير معروف'}`, 'error');
        }
      });

      /* ── المرحلة 3: التجميع ── */
      setPhase('📦 المرحلة 3: تجميع الموقع');
      addLog('packager', '📦 جاري تجميع جميع الأجزاء في ملف واحد...', 'info');

      const assembled = await runAgent(
        'packager',
        `أنت وكيل التغليف. ادمج جميع المخرجات التالية في ملف HTML واحد متكامل.

قواعد مهمة:
1. أنشئ ملف <!DOCTYPE html> كامل
2. ضع CSS في <style> داخل <head>
3. ضع JavaScript في <script> قبل </body>
4. ادمج المحتوى النصي في هيكل HTML
5. استخدم روابط الصور من وكيل الصور
6. أضف dir="rtl" و lang="ar" على <html>
7. أضف رابط Font Awesome CDN
8. أضف meta viewport للتجاوب
9. أخرج فقط ملف HTML الكامل`,
        `ادمج هذه المخرجات:

=== HTML ===
${html}

=== CSS ===
${css}

=== JavaScript ===
${js}

=== المحتوى (JSON) ===
${content}

=== الوسائط (JSON) ===
${media}`,
        false,
        8192,
      );

      /* ── المرحلة 4: المراجعة ── */
      setPhase('🔍 المرحلة 4: مراجعة الكود');
      addLog('reviewer', '🔍 جاري فحص الكود وإصلاح الأخطاء...', 'info');

      const reviewed = await runAgent(
        'reviewer',
        `أنت مراجع أكواد خبير. راجع ملف HTML التالي وأصلح أي أخطاء.

تحقق من:
1. إغلاق جميع الوسوم بشكل صحيح
2. صحة تنسيقات CSS
3. خلو JavaScript من الأخطاء
4. إمكانية الوصول (alt للصور، aria labels)
5. التجاوب مع الشاشات المختلفة
6. دعم RTL بشكل صحيح

أخرج ملف HTML المصحح الكامل فقط (بدون شرح).`,
        `راجع وأصلح:\n${assembled}`,
        false,
        8192,
      );

      /* ── المرحلة 5: التحسين (متوازي) ── */
      setPhase('🚀 المرحلة 5: تحسين الأداء والتوافق');
      addLog('coordinator', '🔄 إطلاق وكيلي الأداء والتوافق بالتوازي...', 'info');

      const [perfR, compatR] = await Promise.allSettled([
        runAgent(
          'performance',
          `أنت خبير تحسين أداء مواقع الويب. حسّن ملف HTML التالي:
- قلل CSS غير المستخدم
- حسّن JavaScript
- أضف lazy loading للصور
- حسّن الخطوط
- أضف preconnect للموارد الخارجية
أخرج ملف HTML المحسّن الكامل فقط.`,
          `حسّن:\n${reviewed}`,
          false,
          8192,
        ),

        runAgent(
          'compatibility',
          `أنت خبير توافق متصفحات. تأكد من عمل ملف HTML على جميع المتصفحات:
- أضف vendor prefixes لـ CSS
- أضف fallbacks للميزات الحديثة
- تأكد من viewport meta tag
- تأكد من charset
- تأكد من التوافق مع Chrome, Firefox, Safari, Edge
أخرج ملف HTML المتوافق الكامل فقط.`,
          `تأكد من التوافق:\n${reviewed}`,
          false,
          8192,
        ),
      ]);

      // اختر أفضل نتيجة
      let finalResult = reviewed;
      if (perfR.status === 'fulfilled' && perfR.value.length > 100) {
        finalResult = perfR.value;
      }
      if (compatR.status === 'rejected') {
        setStatus('compatibility', 'error');
        addLog('compatibility', `⚠️ ${compatR.reason?.message || 'خطأ'}`, 'warning');
      }
      if (perfR.status === 'rejected') {
        setStatus('performance', 'error');
        addLog('performance', `⚠️ ${perfR.reason?.message || 'خطأ'}`, 'warning');
      }

      // تنظيف النتيجة
      finalResult = finalResult.replace(/```html?\n?/gi, '').replace(/```\s*$/g, '').trim();

      if (!finalResult.toLowerCase().startsWith('<!doctype')) {
        finalResult = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>موقعي</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
${finalResult}
</body>
</html>`;
      }

      setFinalCode(finalResult);
      setActiveTab('preview');
      setPhase('✅ اكتمل البناء');
      addLog('coordinator', '🎉 تم بناء الموقع بنجاح! يمكنك معاينته وتحميله.', 'success');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'خطأ غير معروف';
      addLog('coordinator', `❌ خطأ عام: ${msg}`, 'error');
      setPhase('❌ حدث خطأ');
    } finally {
      setIsRunning(false);
    }
  }, [request, nvidiaKey, groqKey, addLog, runAgent, setStatus]);

  /* ─── Download ─── */
  const downloadCode = useCallback(() => {
    const blob = new Blob([finalCode], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'website.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [finalCode]);

  /* ─── Copy ─── */
  const copyCode = useCallback(() => {
    navigator.clipboard.writeText(finalCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [finalCode]);

  /* ─── Status helpers ─── */
  const sColor = (s: AgentDef['status']) => {
    const m: Record<string, string> = {
      idle: 'bg-gray-600',
      searching: 'bg-yellow-400 animate-pulse shadow-[0_0_8px_rgba(250,204,21,0.6)]',
      coding: 'bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(34,211,238,0.6)]',
      done: 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.4)]',
      error: 'bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.4)]',
    };
    return m[s] || m.idle;
  };

  const sText = (s: AgentDef['status']) => {
    const m: Record<string, string> = {
      idle: 'في الانتظار',
      searching: 'يبحث في المصادر...',
      coding: 'يبرمج...',
      done: 'اكتمل ✓',
      error: 'خطأ ✗',
    };
    return m[s] || '';
  };

  const logColor = (t: LogEntry['type']) => {
    const m: Record<string, string> = {
      info: 'border-blue-500/30 text-blue-200',
      search: 'border-yellow-500/30 text-yellow-200',
      code: 'border-purple-500/30 text-purple-200',
      success: 'border-emerald-500/30 text-emerald-200',
      error: 'border-red-500/30 text-red-200',
      warning: 'border-orange-500/30 text-orange-200',
    };
    return m[t] || m.info;
  };

  const doneCount = agents.filter((a) => a.status === 'done').length;
  const workingCount = agents.filter((a) => a.status === 'searching' || a.status === 'coding').length;

  /* ═══════════════════════════════════════════════════════════════
     RENDER
     ═══════════════════════════════════════════════════════════════ */
  return (
    <div dir="rtl" className="min-h-screen text-white" style={{ background: 'linear-gradient(135deg, #04060f 0%, #0a0e27 30%, #111340 60%, #0d0a20 100%)' }}>

      {/* ──── Settings Modal ──── */}
      {showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm" onClick={(e) => e.target === e.currentTarget && setShowSettings(false)}>
          <div className="bg-[#12143a] border border-[#2a2d6a] rounded-2xl p-8 w-full max-w-lg shadow-2xl shadow-purple-900/30 animate-slide-in">
            <div className="text-center mb-8">
              <span className="text-4xl">⚙️</span>
              <h2 className="text-2xl font-bold mt-3 bg-gradient-to-l from-cyan-400 to-purple-400 bg-clip-text text-transparent">إعدادات مفاتيح API</h2>
              <p className="text-gray-400 text-sm mt-2">مفتاح واحد لكل مزود — يُستخدم مع 5 نماذج مختلفة</p>
            </div>

            <div className="space-y-6">
              {/* NVIDIA */}
              <div className="p-4 rounded-xl border border-green-500/20 bg-green-500/5">
                <label className="flex items-center gap-2 text-sm font-bold text-green-300 mb-3">
                  <span className="w-3 h-3 rounded-full bg-green-400" /> مفتاح NVIDIA API
                </label>
                <input
                  type="password"
                  value={nvidiaKey}
                  onChange={(e) => setNvidiaKey(e.target.value)}
                  className="w-full px-4 py-3 bg-[#080a1f] border border-[#2a2d6a] rounded-xl text-white placeholder-gray-600 focus:border-green-400 focus:outline-none transition-colors font-mono text-sm"
                  placeholder="nvapi-..."
                  dir="ltr"
                />
                <div className="mt-3 flex flex-wrap gap-1">
                  {NVIDIA_MODELS.map((m) => (
                    <span key={m} className="text-[10px] px-2 py-0.5 bg-green-900/30 rounded-full text-green-300 border border-green-500/20">{m.split('/').pop()}</span>
                  ))}
                </div>
              </div>

              {/* Groq */}
              <div className="p-4 rounded-xl border border-orange-500/20 bg-orange-500/5">
                <label className="flex items-center gap-2 text-sm font-bold text-orange-300 mb-3">
                  <span className="w-3 h-3 rounded-full bg-orange-400" /> مفتاح Groq API
                </label>
                <input
                  type="password"
                  value={groqKey}
                  onChange={(e) => setGroqKey(e.target.value)}
                  className="w-full px-4 py-3 bg-[#080a1f] border border-[#2a2d6a] rounded-xl text-white placeholder-gray-600 focus:border-orange-400 focus:outline-none transition-colors font-mono text-sm"
                  placeholder="gsk_..."
                  dir="ltr"
                />
                <div className="mt-3 flex flex-wrap gap-1">
                  {GROQ_MODELS.map((m) => (
                    <span key={m} className="text-[10px] px-2 py-0.5 bg-orange-900/30 rounded-full text-orange-300 border border-orange-500/20">{m}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-8">
              <button onClick={() => setShowSettings(false)} className="flex-1 py-3 rounded-xl font-bold transition-all bg-gradient-to-l from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-lg">
                ✅ حفظ وإغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ──── Header ──── */}
      <header className="border-b border-[#1e2050] bg-[#060818]/90 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-[1600px] mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center text-xl shadow-lg shadow-purple-500/20">🤖</div>
            <div>
              <h1 className="text-lg font-bold bg-gradient-to-l from-cyan-300 via-blue-300 to-purple-400 bg-clip-text text-transparent">
                منصة وكلاء المبرمجين المتوازيين
              </h1>
              <p className="text-[11px] text-gray-500">10 وكلاء ذكاء اصطناعي • 5 نماذج NVIDIA + 5 نماذج Groq • بحث في 15 مصدر</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Status badges */}
            <div className="hidden sm:flex gap-2 text-[11px]">
              <span className={`px-2.5 py-1 rounded-full border ${nvidiaKey ? 'bg-green-900/20 text-green-300 border-green-500/30' : 'bg-red-900/20 text-red-300 border-red-500/30'}`}>
                NVIDIA {nvidiaKey ? '✓' : '✗'}
              </span>
              <span className={`px-2.5 py-1 rounded-full border ${groqKey ? 'bg-green-900/20 text-green-300 border-green-500/30' : 'bg-red-900/20 text-red-300 border-red-500/30'}`}>
                Groq {groqKey ? '✓' : '✗'}
              </span>
            </div>
            {isRunning && (
              <div className="text-[11px] text-cyan-300 animate-pulse">{phase}</div>
            )}
            <button
              onClick={() => setShowSettings(true)}
              className="w-9 h-9 rounded-xl bg-[#1a1d4a] hover:bg-[#252866] border border-[#2a2d6a] flex items-center justify-center transition-colors text-lg"
              title="الإعدادات"
            >⚙️</button>
          </div>
        </div>
      </header>

      {/* ──── Input Bar ──── */}
      <div className="max-w-[1600px] mx-auto px-4 py-4">
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <input
              value={request}
              onChange={(e) => setRequest(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !isRunning && startWorkflow()}
              className="w-full px-5 py-3.5 bg-[#0d1025] border border-[#2a2d6a] rounded-xl text-white placeholder-gray-600 focus:border-cyan-500 focus:shadow-[0_0_20px_rgba(6,182,212,0.15)] focus:outline-none transition-all text-base"
              placeholder="💡 اكتب طلبك هنا... مثال: صفحة هبوط لتطبيق جوال، موقع شركة تقنية، لعبة بسيطة..."
              disabled={isRunning}
            />
          </div>
          <button
            onClick={startWorkflow}
            disabled={isRunning || !request.trim()}
            className={`px-8 py-3.5 rounded-xl font-bold text-base transition-all whitespace-nowrap ${
              isRunning
                ? 'bg-[#1a1d4a] text-gray-500 cursor-not-allowed'
                : 'bg-gradient-to-l from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/30 hover:-translate-y-0.5'
            }`}
          >
            {isRunning ? '⏳ جاري العمل...' : '🚀 ابدأ البناء'}
          </button>
        </div>

        {/* Progress bar */}
        {isRunning && (
          <div className="mt-3 h-1.5 bg-[#1a1d4a] rounded-full overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-l from-cyan-400 to-purple-500 transition-all duration-1000 ease-out"
              style={{ width: `${(doneCount / 10) * 100}%` }}
            />
          </div>
        )}
      </div>

      {/* ──── Main Grid ──── */}
      <div className="max-w-[1600px] mx-auto px-4 pb-28 grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-4">

        {/* ── Agents Panel ── */}
        <div className="bg-[#0d1025]/80 border border-[#1e2050] rounded-xl overflow-hidden lg:sticky lg:top-[70px] lg:self-start">
          <div className="p-4 border-b border-[#1e2050] bg-[#111340]/50">
            <div className="flex items-center justify-between">
              <h2 className="font-bold flex items-center gap-2">
                👥 فريق الوكلاء
              </h2>
              <div className="flex gap-2 text-[11px]">
                {workingCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-cyan-900/30 text-cyan-300 border border-cyan-500/20 animate-pulse">
                    {workingCount} يعملون
                  </span>
                )}
                <span className="px-2 py-0.5 rounded-full bg-[#1a1d4a] text-gray-300 border border-[#2a2d6a]">
                  {doneCount}/10
                </span>
              </div>
            </div>
          </div>

          <div className="p-3 space-y-1.5 max-h-[calc(100vh-200px)] overflow-y-auto">
            {agents.map((agent) => (
              <div
                key={agent.id}
                className={`flex items-center gap-3 p-3 rounded-xl border transition-all duration-500 ${
                  agent.status === 'searching' || agent.status === 'coding'
                    ? 'border-cyan-500/40 bg-cyan-900/10 shadow-[0_0_20px_rgba(6,182,212,0.08)]'
                    : agent.status === 'done'
                    ? 'border-emerald-500/20 bg-emerald-900/5'
                    : agent.status === 'error'
                    ? 'border-red-500/20 bg-red-900/5'
                    : 'border-[#1e2050] bg-transparent hover:bg-[#111340]/30'
                }`}
              >
                <span className="text-xl w-8 text-center flex-shrink-0">{agent.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium">{agent.name}</div>
                  <div className="text-[10px] text-gray-500 truncate">{agent.role}</div>
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className={`text-[9px] px-1.5 py-0.5 rounded ${agent.provider === 'nvidia' ? 'bg-green-900/30 text-green-400' : 'bg-orange-900/30 text-orange-400'}`}>
                      {agent.provider === 'nvidia' ? 'NVIDIA' : 'Groq'}
                    </span>
                    <span className="text-[9px] text-gray-600 truncate" dir="ltr">{agent.model.split('/').pop()}</span>
                  </div>
                </div>
                <div className="flex flex-col items-center gap-1 flex-shrink-0">
                  <div className={`w-2.5 h-2.5 rounded-full ${sColor(agent.status)}`} />
                  <span className="text-[9px] text-gray-500 whitespace-nowrap">{sText(agent.status)}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Sources summary */}
          <div className="p-3 border-t border-[#1e2050] bg-[#111340]/30">
            <div className="text-[10px] text-gray-500 mb-2 font-medium">📚 المصادر المتصلة ({Object.keys(SOURCES).length})</div>
            <div className="flex flex-wrap gap-1">
              {Object.values(SOURCES).map((s) => (
                <span key={s.name} className="text-[9px] px-1.5 py-0.5 bg-[#1a1d4a] rounded text-gray-400 border border-[#2a2d6a]/50" title={s.desc}>
                  {s.name}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* ── Work Area ── */}
        <div className="space-y-4">
          {/* Tabs */}
          <div className="flex items-center gap-2 flex-wrap">
            {(['log', 'code', 'preview'] as const).map((tab) => {
              const labels = { log: '📋 سجل العمل', code: '💻 الكود المصدري', preview: '👁️ معاينة حية' };
              const disabled = tab !== 'log' && !finalCode;
              return (
                <button
                  key={tab}
                  onClick={() => !disabled && setActiveTab(tab)}
                  className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    activeTab === tab
                      ? 'bg-gradient-to-l from-cyan-600 to-purple-600 text-white shadow-lg'
                      : disabled
                      ? 'bg-[#0d1025] text-gray-700 cursor-not-allowed border border-[#1e2050]'
                      : 'bg-[#0d1025] text-gray-400 hover:text-white hover:bg-[#1a1d4a] border border-[#1e2050]'
                  }`}
                >
                  {labels[tab]}
                  {tab === 'log' && logs.length > 0 && (
                    <span className="mr-1.5 text-[10px] bg-white/10 px-1.5 py-0.5 rounded-full">{logs.length}</span>
                  )}
                </button>
              );
            })}

            {finalCode && (
              <div className="flex gap-2 mr-auto">
                <button
                  onClick={copyCode}
                  className="px-4 py-2.5 bg-[#0d1025] hover:bg-[#1a1d4a] rounded-xl text-sm border border-[#1e2050] transition-colors"
                >
                  {copied ? '✅ تم النسخ' : '📋 نسخ'}
                </button>
                <button
                  onClick={downloadCode}
                  className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-600 rounded-xl text-sm font-medium transition-colors shadow-lg shadow-emerald-900/20"
                >
                  💾 تحميل HTML
                </button>
              </div>
            )}
          </div>

          {/* Tab Content */}
          <div className="bg-[#0d1025]/80 border border-[#1e2050] rounded-xl overflow-hidden shadow-2xl shadow-black/20" style={{ minHeight: 520 }}>

            {/* ── Log Tab ── */}
            {activeTab === 'log' && (
              <div className="p-4 overflow-y-auto font-mono text-[13px] space-y-1.5" style={{ maxHeight: 600 }}>
                {logs.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-24 text-gray-600">
                    <div className="text-7xl mb-6 opacity-40">🤖</div>
                    <p className="text-lg font-medium mb-2">جاهز للعمل</p>
                    <p className="text-sm">اكتب طلبك واضغط "ابدأ البناء" لتشغيل فريق الوكلاء</p>
                    <div className="mt-6 grid grid-cols-2 gap-4 text-[11px] text-gray-500 max-w-md">
                      <div className="p-3 rounded-lg border border-[#1e2050] bg-[#111340]/30">
                        <span className="text-green-400">NVIDIA</span> — 5 نماذج للتنسيق والتصميم والمحتوى والتدقيق والأداء
                      </div>
                      <div className="p-3 rounded-lg border border-[#1e2050] bg-[#111340]/30">
                        <span className="text-orange-400">Groq</span> — 5 نماذج للهياكل والحركة والصور والتغليف والتوافق
                      </div>
                    </div>
                  </div>
                )}
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className={`flex gap-3 items-start py-2 px-3 rounded-lg border-r-2 bg-[#080a1f]/50 animate-slide-in ${logColor(log.type)}`}
                  >
                    <span className="text-base flex-shrink-0">{log.agentIcon}</span>
                    <span className="text-[11px] text-gray-600 whitespace-nowrap pt-0.5 flex-shrink-0 font-sans" dir="ltr">
                      {log.time}
                    </span>
                    <span className="text-[11px] text-gray-500 whitespace-nowrap pt-0.5 flex-shrink-0 font-sans">
                      {log.agentName}
                    </span>
                    <span className="flex-1 leading-relaxed">{log.message}</span>
                  </div>
                ))}
                <div ref={logEndRef} />
              </div>
            )}

            {/* ── Code Tab ── */}
            {activeTab === 'code' && (
              <div className="p-5 overflow-auto" style={{ maxHeight: 600 }}>
                {finalCode ? (
                  <pre
                    className="text-[13px] font-mono text-emerald-300/90 whitespace-pre-wrap leading-relaxed selection:bg-purple-500/30"
                    dir="ltr"
                    style={{ tabSize: 2 }}
                  >
                    {finalCode}
                  </pre>
                ) : (
                  <div className="flex items-center justify-center py-24 text-gray-600">
                    <p>لم يتم إنشاء كود بعد...</p>
                  </div>
                )}
              </div>
            )}

            {/* ── Preview Tab ── */}
            {activeTab === 'preview' && (
              <div style={{ height: 600 }}>
                {finalCode ? (
                  <iframe
                    srcDoc={finalCode}
                    className="w-full h-full border-0 bg-white rounded-b-xl"
                    sandbox="allow-scripts allow-same-origin"
                    title="معاينة الموقع"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-600">
                    <p>لم يتم إنشاء موقع بعد...</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Models info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-4 rounded-xl border border-green-500/10 bg-green-500/5">
              <div className="flex items-center gap-2 text-sm font-bold text-green-300 mb-3">
                <span className="w-2 h-2 rounded-full bg-green-400" />
                نماذج NVIDIA (5)
              </div>
              <div className="space-y-1">
                {NVIDIA_MODELS.map((m, i) => {
                  const agentNames = INITIAL_AGENTS.filter(a => a.provider === 'nvidia');
                  return (
                    <div key={m} className="flex justify-between text-[11px] py-1 px-2 rounded bg-green-900/10">
                      <span className="text-green-300/70" dir="ltr">{m}</span>
                      <span className="text-gray-500">{agentNames[i]?.icon} {agentNames[i]?.name}</span>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="p-4 rounded-xl border border-orange-500/10 bg-orange-500/5">
              <div className="flex items-center gap-2 text-sm font-bold text-orange-300 mb-3">
                <span className="w-2 h-2 rounded-full bg-orange-400" />
                نماذج Groq (5)
              </div>
              <div className="space-y-1">
                {GROQ_MODELS.map((m, i) => {
                  const agentNames = INITIAL_AGENTS.filter(a => a.provider === 'groq');
                  return (
                    <div key={m} className="flex justify-between text-[11px] py-1 px-2 rounded bg-orange-900/10">
                      <span className="text-orange-300/70" dir="ltr">{m}</span>
                      <span className="text-gray-500">{agentNames[i]?.icon} {agentNames[i]?.name}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ──── Intervention Bar ──── */}
      {isRunning && (
        <div className="fixed bottom-0 inset-x-0 bg-[#0d1025]/95 backdrop-blur-xl border-t border-[#1e2050] py-3 px-4 z-40">
          <div className="max-w-[1600px] mx-auto flex gap-3 items-center">
            <div className="text-yellow-400 text-xl flex-shrink-0">✋</div>
            <input
              value={intervention}
              onChange={(e) => setIntervention(e.target.value)}
              className="flex-1 px-4 py-2.5 bg-[#080a1f] border border-[#2a2d6a] rounded-xl text-white placeholder-gray-600 focus:border-yellow-500 focus:outline-none transition-colors text-sm"
              placeholder="أضف تعليمات إضافية للوكلاء أثناء العمل..."
            />
            <button
              onClick={() => {
                if (intervention.trim()) {
                  addLog('coordinator', `👤 تدخل المستخدم: ${intervention}`, 'warning');
                  setIntervention('');
                }
              }}
              className="px-6 py-2.5 bg-yellow-600 hover:bg-yellow-500 rounded-xl font-bold transition-colors text-sm flex-shrink-0"
            >
              إرسال التعليمات
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
